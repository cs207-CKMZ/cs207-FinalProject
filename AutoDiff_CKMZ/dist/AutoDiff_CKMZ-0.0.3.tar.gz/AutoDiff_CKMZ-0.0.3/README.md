# Automatic Differentiation Package
## Group 18
See docs folder for more details on how to dowload and use this package
